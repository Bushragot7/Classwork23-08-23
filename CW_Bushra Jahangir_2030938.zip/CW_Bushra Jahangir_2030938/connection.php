<?php
$url='localhost';
$username="root";
$password="";
$dbname="school";
$conn= mysqli_connect($url, $username, $$password, $dbname);

if (!$con){
    die("Connection failed:" .mysqli_connect_error());
}
?>